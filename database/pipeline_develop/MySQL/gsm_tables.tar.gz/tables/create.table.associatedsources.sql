/**
 * This table stores the information about the sources that
 * could be associated.
 * src_type:        Either 'X' or 'C', for associations 
 *                  in extractedsources or catalogedsources
 * xrtsrc_id:       This is the xtrsrcid that corresponds to the 
 *                  first detection
 * assoc_xtrsrcid:  This is the id of the source that could be 
 *                  associated to a previously detection 
 *                  (corresponding to assoc_xtrsrcid)
 */
CREATE TABLE associatedsources (
  id INT NOT NULL AUTO_INCREMENT,
  xtrsrc_id INT NOT NULL,
  insert_src1 BOOLEAN NULL,
  src_type CHAR(1) NOT NULL,
  assoc_xtrsrcid INT NULL,
  insert_src2 BOOLEAN NULL,
  assoc_catsrcid INT NULL,
  assoc_class_id INT NULL,
  PRIMARY KEY (id),
  UNIQUE INDEX (xtrsrc_id),
  FOREIGN KEY (xtrsrc_id) REFERENCES extractedsources (xtrsrcid),
  INDEX (assoc_xtrsrcid),
  FOREIGN KEY (assoc_xtrsrcid) REFERENCES extractedsources (xtrsrcid),
  INDEX (assoc_catsrcid),
  FOREIGN KEY (assoc_catsrcid) REFERENCES catalogedsources (catsrcid),
  INDEX (assoc_class_id),
  FOREIGN KEY (assoc_class_id) REFERENCES associationclass (assoc_classid)
) ENGINE=InnoDB;
