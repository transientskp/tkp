/**
 * This table contains the information about the dataset that is produced by LOFAR. 
 * A dataset has an integration time and consists of multiple frequency layers.
 * taustart_timestamp:  the start time of the integration
 */
CREATE TABLE datasets (
  dsid INT NOT NULL AUTO_INCREMENT,
  rerun INT NOT NULL DEFAULT '0',
  dstype SMALLINT NOT NULL,
  taustart_timestamp BIGINT NOT NULL, 
  dsinname VARCHAR(50) NOT NULL,
  dsoutname VARCHAR(50) DEFAULT NULL,
  description VARCHAR(100) DEFAULT NULL,
  PRIMARY KEY (dsid),
  INDEX (taustart_timestamp)
) ENGINE=InnoDB;
