DROP TABLE IF EXISTS assoccatsrcids;
