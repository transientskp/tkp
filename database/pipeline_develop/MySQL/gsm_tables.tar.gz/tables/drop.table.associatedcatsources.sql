DROP TABLE IF EXISTS associatedcatsources;
