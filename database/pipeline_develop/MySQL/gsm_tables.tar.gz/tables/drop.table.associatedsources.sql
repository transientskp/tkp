DROP TABLE IF EXISTS associatedsources;
