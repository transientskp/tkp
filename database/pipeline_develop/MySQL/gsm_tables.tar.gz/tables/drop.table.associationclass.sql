DROP TABLE IF EXISTS associationclass;
