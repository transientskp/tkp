DROP TABLE IF EXISTS assocxtrsrcids;
