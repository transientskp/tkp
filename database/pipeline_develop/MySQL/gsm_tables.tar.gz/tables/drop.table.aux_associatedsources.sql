DROP TABLE IF EXISTS aux_associatedsources;
