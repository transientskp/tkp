DROP TABLE IF EXISTS averagedsources;
