DROP TABLE IF EXISTS catalogedsources;
