DROP TABLE IF EXISTS extractedsources;
