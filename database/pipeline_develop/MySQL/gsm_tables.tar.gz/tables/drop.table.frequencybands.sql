DROP TABLE IF EXISTS frequencybands;
