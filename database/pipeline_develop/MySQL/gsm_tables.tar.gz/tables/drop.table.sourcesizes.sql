DROP TABLE IF EXISTS sourcesizes;
